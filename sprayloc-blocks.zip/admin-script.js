"use_strict";


window.addEventListener("DOMContentLoaded", function(){

})
